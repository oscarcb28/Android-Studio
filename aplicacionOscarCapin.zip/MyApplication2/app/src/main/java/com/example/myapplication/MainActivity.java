package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    TextView contador;
    Button botonMejora1;
    ImageView coin_image;

    int cont = 0;
    int valorClick = 1;
    int costeBillete = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final MediaPlayer clickSoundMediaPlayer = MediaPlayer.create(this, R.raw.click);

        final Button playClick = (Button) this.findViewById(R.id.button1);

        playClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickSoundMediaPlayer.start();
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coin_image=(ImageView)findViewById(R.id.diamond);
        botonMejora1=(Button)findViewById(R.id.button1);
        contador = (TextView) findViewById(R.id.textcontador);
        contador.setText("" + cont);
    }

    public void irainicio (View v) {
        finish();
    }

    public void sumar(View v) {
        ScaleAnimation fade_in = new ScaleAnimation(0.7f, 1.2f, 0.7f, 1.2f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        fade_in.setDuration(100);
        coin_image.startAnimation(fade_in);
        cont = cont + valorClick;
        contador.setText("" + cont);
        // contador.setText("" + cont); al concatenar un String a un int,
        // se crea un String de ambos
    }

    public void mejora1(View v) {
        if (cont >= costeBillete) {
            cont = cont - costeBillete;
            valorClick++;
            contador.setText(""+ cont);
            costeBillete = costeBillete + 20;
            botonMejora1.setText(costeBillete + " diamantes");
        }
    }

    public void callClick(View view) {
        final MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.click);
        mediaPlayer.start();
    }

}