package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PantallaInicio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_inicio);
    }
    public void iraljuego (View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);

    }

    public void irainfo (View v) {
        Intent i = new Intent(this, PantallaInformacion.class);
        startActivity(i);
    }

    public void iraopciones (View v) {
        Intent i = new Intent(this, PantallaOpciones.class);
        startActivity(i);
    }

    public void salir (View v) {
        finish();
    }
}